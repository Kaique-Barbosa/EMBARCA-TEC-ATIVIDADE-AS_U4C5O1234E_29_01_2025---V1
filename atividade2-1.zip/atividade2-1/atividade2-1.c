/*
 * Descrição: Controle de LED RGB representando um semáforo, com tempo de 3 segundos para cada cor.
 * Autor: Kaique
 */

#include "pico/stdlib.h"
#include "hardware/timer.h"
#include <stdio.h>

// Definindo os pinos para o LED RGB
#define LED_VERMELHO 11
#define LED_VERDE 12
#define LED_AZUL 13  // Usado para representar o amarelo

// Variável para controlar o estado do semáforo
volatile int estado_semaforo = 0;

// Função chamada periodicamente pelo temporizador
bool controlar_semaforo(repeating_timer_t *t) {
    switch (estado_semaforo) {
        case 0: // Vermelho
            gpio_put(LED_VERMELHO, 1);
            gpio_put(LED_VERDE, 0);
            gpio_put(LED_AZUL, 0);
            printf("Semáforo: Vermelho\n"); // Imprime quando o LED vermelho é ligado
            break;
        case 1: // Amarelo (usando o LED azul para representar o amarelo)
            gpio_put(LED_VERMELHO, 0);
            gpio_put(LED_VERDE, 0);
            gpio_put(LED_AZUL, 1);
            printf("Semáforo: Amarelo\n"); // Imprime quando o LED azul é ligado
            break;
        case 2: // Verde
            gpio_put(LED_VERMELHO, 0);
            gpio_put(LED_VERDE, 1);
            gpio_put(LED_AZUL, 0);
            printf("Semáforo: Verde\n"); // Imprime quando o LED verde é ligado
            break;
    }
    estado_semaforo = (estado_semaforo + 1) % 3;  
    return true; // Mantém o temporizador repetindo
}

int main() {
    stdio_init_all();

    // Configura os pinos do LED RGB como saída
    gpio_init(LED_VERMELHO);
    gpio_set_dir(LED_VERMELHO, GPIO_OUT);

    gpio_init(LED_VERDE);
    gpio_set_dir(LED_VERDE, GPIO_OUT);

    gpio_init(LED_AZUL);
    gpio_set_dir(LED_AZUL, GPIO_OUT);

    // Cria um temporizador repetitivo com intervalo de 3000 ms (3 segundos)
    repeating_timer_t temporizador;
    add_repeating_timer_ms(3000, controlar_semaforo, NULL, &temporizador);

    // Loop infinito para manter o programa em execução
    while (true) {
        sleep_ms(100);  
    }

    return 0;
}