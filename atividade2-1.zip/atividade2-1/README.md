para testar o codigo basta rodalo na simulação ou subir para a placa.

funcionamento: A cada 3 segundos ira acender o led na sequencia (vermelho, amarelo(azul), verde), entre eles existe um intervalo de 3 segundos. a cada troca de cor do led é impresso no terminal a sua respectiva cor.
