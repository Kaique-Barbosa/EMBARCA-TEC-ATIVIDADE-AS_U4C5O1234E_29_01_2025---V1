// autor: kaique


para testar o codigo basta rodar no simulador wokwi no vscode ou subir para a placa

instruções:

deve-se pressionar o botão para acender os leds e os mesmos irem apagando com intervalo de 3 segundos, seguindo a ordem (vermelho, azul e verde).