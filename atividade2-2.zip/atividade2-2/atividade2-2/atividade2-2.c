#include "pico/stdlib.h"
#include "hardware/timer.h"
#include <stdio.h>

// Definindo os pinos para os LEDs e o botão
#define LED_VERMELHO 11
#define LED_VERDE 12
#define LED_AZUL 13
#define BOTAO 5

// Variável para controlar o estado dos LEDs
volatile int estado_leds = 0;

// Variável para controlar se o botão pode ser pressionado
volatile bool botao_habilitado = true;

// Função de callback para o temporizador
int64_t callback_temporizador(alarm_id_t id, void *user_data) {
    switch (estado_leds) {
        case 1: // Apaga o LED vermelho primeiro
            gpio_put(LED_VERMELHO, 0);
            estado_leds = 2;
            break;
        case 2: // Apaga o LED azul
            gpio_put(LED_AZUL, 0);
            estado_leds = 3;
            break;
        case 3: // Apaga o LED verde (todos desligados)
            gpio_put(LED_VERDE, 0);
            estado_leds = 0;
            botao_habilitado = true; // Habilita o botão novamente
            return 0; // Finaliza o temporizador
    }
    return 3000000; // Próxima mudança após 3 segundos (3.000.000 microssegundos)
}

// Função para tratar o pressionamento do botão
void tratar_botao() {
    if (botao_habilitado) {
        botao_habilitado = false; // Desabilita o botão durante a execução
        estado_leds = 1; // Define o estado inicial

        // **Acende os LEDs imediatamente**
        gpio_put(LED_VERMELHO, 1);
        gpio_put(LED_VERDE, 1);
        gpio_put(LED_AZUL, 1);

        // Inicia o temporizador após 3 segundos
        add_alarm_in_ms(3000, callback_temporizador, NULL, false);
    }
}

// Função principal
int main() {
    stdio_init_all();

    // Configura os pinos dos LEDs como saída
    gpio_init(LED_VERMELHO);
    gpio_set_dir(LED_VERMELHO, GPIO_OUT);
    gpio_init(LED_VERDE);
    gpio_set_dir(LED_VERDE, GPIO_OUT);
    gpio_init(LED_AZUL);
    gpio_set_dir(LED_AZUL, GPIO_OUT);

    // Configura o pino do botão como entrada com pull-up
    gpio_init(BOTAO);
    gpio_set_dir(BOTAO, GPIO_IN);
    gpio_pull_up(BOTAO);

    // Loop infinito para monitorar o botão
    while (true) {
        if (!gpio_get(BOTAO)) { // Verifica se o botão foi pressionado (nível baixo)
            tratar_botao();
            sleep_ms(300); // Debounce simples
        }
        sleep_ms(100); // Evita uso excessivo da CPU
    }

    return 0;
}
